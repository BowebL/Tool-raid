# Tool-raid
hey je me presente je suis boweb alors le tool
c'est pour raid tres vite avec le prefix #
tool raid discord bot by boweb
ß oweb ceci est un tool pour raid un serveur tres vite :) en code py open source